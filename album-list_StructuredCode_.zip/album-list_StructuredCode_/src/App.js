import AlbumList from "./Components/AlbumList/AlbumList";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { useState, useEffect } from "react";
import AddAlbum from "./Components/AddAlbum/AddAlbum";
import Navbar from "./Components/Navbar/Navbar";
import UpdateAlbum from "./Components/UpdateAlbum/UpdateAlbum";

// App component
function App() {
  // State variables
  const [albums, setAlbums] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [add, setAdd] = useState(true);

  // Fetch albums data on component mount
  useEffect(() => {
    async function fetchingAlbum() {
      try {
        const response = await fetch("https://jsonplaceholder.typicode.com/albums");
        if (!response.ok) {
          throw new Error("Error fetching data");
        }
        const json = await response.json();
        setAlbums(json);
        setIsLoading(false);
      } catch (error) {
        console.error("Error:", error.message);
      }
    }
    fetchingAlbum();
  }, []);

  // Function to add new album
  const addAlbum = (newAlbum) => {
    setAlbums([...albums, newAlbum]);
  };

  // Function to update album
  const updateAlbum = (updatedAlbum) => {
    setAlbums(updatedAlbum);
  };

  // Function to handle adding album
  const handleAddAlbum = () => {
    setAdd(false);
  };

  // Function to handle going back to home
  const handleBackHome = () => {
    setAdd(true);
  };

  // Function to handle deleting album
  const handleDelete = async (id) => {
    try {
      await fetch(`https://jsonplaceholder.typicode.com/albums/${id}`, {
        method: 'DELETE',
      });
      setAlbums(albums.filter((album) => album.id !== id));
    } catch (error) {
      console.error("Error:", error.message);
    }
  };

  // Create browser router configuration
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Navbar add={add} handleAddAlbum={handleAddAlbum} handleBackHome={handleBackHome} />,
      children: [
        { index: true, element: <AlbumList albums={albums} handleDelete={handleDelete} handleAddAlbum={handleAddAlbum} /> },
        { path: "/addAlbum", element: <AddAlbum addAlbum={addAlbum} handleBackHome={handleBackHome} /> },
        { path: "/updateAlbum/:id", element: <UpdateAlbum albums={albums} updateAlbum={updateAlbum} handleBackHome={handleBackHome} /> }
      ]
    }
  ]);

  // Render loading message if data is still loading
  if (isLoading) {
    return <h3>Loading...</h3>;
  }

  // Render the app with router provider
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

// Export the App component
export default App;

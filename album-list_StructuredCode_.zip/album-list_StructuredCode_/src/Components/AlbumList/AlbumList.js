// Import necessary modules and components
import React from "react";
import List from "../List/List.js"; // Assuming the path is correct
import "./AlbumList.css";

// Functional component AlbumList
function AlbumList({ albums, handleDelete, handleAddAlbum }) {
    // Render the list of albums
    return (
        <div className="albumlist-container">
            {/* Map through the albums array and render List component for each album */}
            {albums.map((album, key) => {
                return <List key={key} className="list" album={album} index={key} handleDelete={handleDelete} handleAddAlbum={handleAddAlbum} />;
            })}
        </div>
    );
}

// Export the component
export default AlbumList;

import { useNavigate } from "react-router-dom";
import "./AddAlbum.css";
import { useState } from "react";

function AddAlbum({ addAlbum, handleBackHome }) {

    // State initialization
    const [albumData, setAlbumData] = useState({ title: "", userId: "" });

    // Navigation hook
    const navigate = useNavigate();

    // Form submission handler
    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent default form submission behavior
        try {
            // Generate unique ID based on current timestamp
            const id = Date.now();
            // Send POST request to create a new album
            const response = await fetch("https://jsonplaceholder.typicode.com/albums", {
                method: "POST",
                body: JSON.stringify({ ...albumData, id }),
                headers: {
                    "Content-Type": "application/json"
                }
            });
            if (!response.ok) {
                throw new Error("Failed to find an Album");
            }
            // Parse response JSON to get the new album data
            const newAlbum = await response.json();
            // Add the new album to the state
            addAlbum(newAlbum);
            // Reset the form input fields
            setAlbumData({ title: "", userId: "" });
        } catch (error) {
            console.error("Error:", error.message);
        }
        // Navigate back to the home page
        handleBackHome();
        navigate("/");
    };

    // JSX structure
    return (
        <>
            <div className="addAlbum-container" >
                <h2>Add new album :</h2>
                <form onSubmit={handleSubmit} >
                    <input
                        type="text"
                        placeholder="Enter album title"
                        name="title"
                        value={albumData.title}
                        onChange={(e) => setAlbumData({ title: e.target.value, userId: albumData.userId })}
                        required
                    />
                    <input
                        type="number"
                        placeholder="Enter User ID"
                        name="userId"
                        value={albumData.userId}
                        onChange={(e) => setAlbumData({ title: albumData.title, userId: e.target.value })}
                        required
                    />
                    <button className="btn">Submit</button>
                </form>
            </div>
        </>
    );
}

export default AddAlbum;

// Import necessary modules and styles
import React from "react";
import { Link } from "react-router-dom"; // Assuming this is the correct import path
import "./List.css";

// Functional component List
function List({ album, handleDelete, handleAddAlbum }) {
    // Render the album details and action buttons
    return (
        <>
            {/* Container for each album */}
            <div className="album-container">
                {/* Display album ID and title */}
                <div className="title">
                    <span>Album : {album.id}</span>
                    <h3>{album.title}</h3>
                </div>
                {/* Link to update album page */}
                <Link to={`/updateAlbum/${album.id}`}>
                    <button className="update" onClick={handleAddAlbum}>Update</button>
                </Link>
                {/* Button to delete album */}
                <button className="delete" onClick={() => handleDelete(album.id)}>Delete</button>
            </div>
        </>
    );
}

// Export the component
export default List;

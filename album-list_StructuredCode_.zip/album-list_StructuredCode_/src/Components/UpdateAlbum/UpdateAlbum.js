// Import necessary modules
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useParams } from "react-router-dom";

// Functional component UpdateAlbum
function UpdateAlbum({ albums, updateAlbum, handleBackHome }) {
    // Extract the id parameter from the URL
    const { id } = useParams();
    // Find the album with matching id
    const albumToUpdate = albums.find((album) => album.id === parseInt(id));
    // State for album data
    const [albumData, setAlbumData] = useState({ title: albumToUpdate.title, userId: albumToUpdate.userId, id: albumToUpdate.id });
    // Hook to navigate between routes
    const navigate = useNavigate();

    // Function to handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // Make PUT request to update the album
            const response = await fetch(`https://jsonplaceholder.typicode.com/albums/${id}`, {
                method: "PUT",
                body: JSON.stringify(albumData),
                headers: {
                    "Content-Type": "application/json"
                }
            });

            if (!response.ok) {
                throw new Error("Failed to find an Album");
            }

            // Get the updated album data
            const updatedAlbum = await response.json();
            // Find the index of the updated album in the albums array
            const index = albums.findIndex((album) => album.id === updatedAlbum.id);
            console.log("updatedAlbum:", updatedAlbum);
            // Create a copy of the albums array
            const updatedAlbums = [...albums];
            // Update the album at the found index with the updated album data
            updatedAlbums[index] = updatedAlbum;
            // Call the updateAlbum function with the updated albums array
            updateAlbum(updatedAlbums);
            // Reset albumData state
            setAlbumData({ title: "", id: "", userId: "" });
        } catch (error) {
            console.error("Error:", error.message);
        }
        // Call handleBackHome function and navigate to the home page
        handleBackHome();
        navigate("/");
    };

    // Render the UpdateAlbum form
    return (
        <>
            <div className="addAlbum-container">
                <h2>Update your album :</h2>
                <form onSubmit={handleSubmit}>
                    <input
                        type="text"
                        placeholder="Enter album title"
                        name="title"
                        value={albumData.title}
                        onChange={(e) => setAlbumData({ title: e.target.value, userId: albumData.userId })}
                        required
                    />
                    <input
                        type="number"
                        placeholder="Enter User ID"
                        name="userId"
                        value={albumData.userId}
                        onChange={(e) => setAlbumData({ title: albumData.title, userId: e.target.value })}
                        required
                    />
                    <button className="btn">Submit</button>
                </form>
            </div>
        </>
    );
}

// Export the UpdateAlbum component
export default UpdateAlbum;

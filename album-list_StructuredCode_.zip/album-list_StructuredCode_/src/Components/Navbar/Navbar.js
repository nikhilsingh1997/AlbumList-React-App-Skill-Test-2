// Import necessary modules and styles
import React from "react";
import { Link, Outlet } from "react-router-dom"; // Assuming this is the correct import path
import "./Navbar.css";

// Functional component Navbar
function Navbar({ add, handleAddAlbum, handleBackHome }) {
    // Render the navigation bar with conditional button based on 'add' prop
    return (
        <>
            {/* Container for the navigation bar */}
            <div className="nav-container">
                {/* Heading */}
                <h2>Album-List</h2>
                {/* Conditional rendering of 'Add Album' or 'Back to Home' button */}
                {add ? (
                    // Link to AddAlbum page
                    <Link to="/addAlbum">
                        <button className="add-btn" onClick={handleAddAlbum}>Add Album</button>
                    </Link>
                ) : (
                    // Link to Home page
                    <Link to="/">
                        <button className="add-btn" onClick={handleBackHome}>Back to home</button>
                    </Link>
                )}
            </div>
            {/* Render the child routes */}
            <Outlet />
        </>
    );
}

// Export the component
export default Navbar;

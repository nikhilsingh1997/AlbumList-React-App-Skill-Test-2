import AlbumList from "./Components/AlbumList/AlbumList";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { useState, useEffect } from "react";
import AddAlbum from "./Components/AddAlbum/AddAlbum";
import Navbar from "./Components/Navbar/Navbar";
import UpdateAlbum from "./Components/UpdateAlbum/UpdateAlbum";

function App() {

  const [albums, setAlbums] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [add, setAdd] = useState(true);
  // const navigate = useNavigate();

  useEffect(()=>{
    async function fetchingAlbum(){
            await fetch("https://jsonplaceholder.typicode.com/albums")
                        .then((response)=> {
                            if( !response.ok){
                                throw new Error("Error to fetch the data");
                            }
                            return response.json();
                        }
                        )
                        .then((json) => {
                            setAlbums(json);
                            setIsLoading(false)
                        }
                        )
    }
    
    fetchingAlbum();

}, []);


  const addAlbum = (newAlbum)=>{
      setAlbums([...albums, newAlbum])
  }

  const updateAlbum = (updatedAlbum) =>{
    setAlbums(updatedAlbum);
  }

  const handleAddAlbum = ()=>{
    setAdd(false);
  }

  const handleBackHome = ()=>{
      setAdd(true);
  }


  const handleDelete = async (id)=>{
      
        await fetch('https://jsonplaceholder.typicode.com/albums/id', {
          method: 'DELETE',
        });
        setAlbums(albums.filter((album)=>  album.id !== id))
  }

  const router = createBrowserRouter([
        {
         path : "/", 
         element : <Navbar  add = {add} handleAddAlbum = {handleAddAlbum} handleBackHome= {handleBackHome} />,
         children : [
            {index : true, element : <AlbumList  albums = {albums}  handleDelete = {handleDelete} handleAddAlbum = {handleAddAlbum}/>},
            {path : "/addAlbum", element : <AddAlbum addAlbum = {addAlbum} handleBackHome= {handleBackHome}  />},
            {path : "/updateAlbum/:id", element : <UpdateAlbum albums = {albums} updateAlbum = {updateAlbum}  handleBackHome= {handleBackHome} />}
         ]},
        
  ])


  if(isLoading){
    return <h3>Loading...</h3>
  } 

  return (
    <div className="App" >
        <RouterProvider router={router}/>
    </div>
  );
}

export default App;

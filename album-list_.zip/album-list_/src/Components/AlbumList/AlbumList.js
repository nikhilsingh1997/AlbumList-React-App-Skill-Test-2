// import { useState, useEffect } from "react";
import  List  from "../List/List.js"
import "./AlbumList.css"


function AlbumList({albums, handleDelete, handleAddAlbum}){
    return(
        <div className="albumlist-container">
            {albums.map((album, key)=> {
                return <List className = "list" album = {album} index = {key}  handleDelete = {handleDelete} handleAddAlbum = {handleAddAlbum}/>
            })}
        </div>
    )
}

export default AlbumList;
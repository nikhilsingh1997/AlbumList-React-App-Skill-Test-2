// import {Link} from "react-router-dom"
import { Link, Outlet } from "react-router-dom";
import "./Navbar.css"

function Navbar({add, handleAddAlbum, handleBackHome}){
        return(
        <>
        <div className = "nav-container" >
                <h2>Album-List</h2>
                { add ? <Link to = "/addAlbum" ><button className="add-btn" onClick = {handleAddAlbum}>Add Album</button></Link> : <Link to = "/" ><button className="add-btn" onClick = {handleBackHome}>Back to home</button></Link>}
        </div>
        <Outlet/>
        </>
    )
}

export default Navbar;
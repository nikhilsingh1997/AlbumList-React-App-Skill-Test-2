import { Link } from "react-router-dom";
import "./List.css"

function List({album, handleDelete, handleAddAlbum}){
    return(
        <>
            <div className="album-container" >
                <div className="title"> <span>Album : {album.id}</span> <h3>{album.title}</h3></div>
                <Link to = {`/updateAlbum/${album.id}`}><button className="update" onClick={handleAddAlbum} >Update</button></Link>
                <button className="delete" onClick = {()=>handleDelete(album.id)} >Delete</button>
            </div>
        </>
    )
}

export default List;
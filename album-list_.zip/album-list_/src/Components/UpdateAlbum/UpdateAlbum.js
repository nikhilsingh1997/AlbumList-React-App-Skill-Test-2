import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useParams } from "react-router-dom";



function UpdateAlbum({ albums, updateAlbum, handleBackHome}){
    const {id} = useParams();
    // Find the album with matching id
    const albumToUpdate = albums.find((album)=> album.id === parseInt(id))
    const [albumData, setAlbumData] = useState({title : albumToUpdate.title, userId : albumToUpdate.userId, id : albumToUpdate.id})
    const navigate = useNavigate();
    console.log("albumdata:",albumData);

    const handleSubmit = async (e)=>{
        e.preventDefault();
        try{
            const response = await fetch(`https://jsonplaceholder.typicode.com/albums/${id}`, {
                    method : "PUT",
                    body : JSON.stringify(albumData),
                    headers : {
                        "Content-Type" : "application/json"
                    }
            })

            if(!response.ok){
                throw new Error("Failed to find an Album")
            }

            const updatedAlbum = await response.json();
            const index = albums.findIndex((album) => album.id === updatedAlbum.id);
            console.log("updatedAlbum:", updatedAlbum);
            const updatedAlbums = [...albums];
            updatedAlbums[index] = updatedAlbum;
            updateAlbum(updatedAlbums);
            setAlbumData({title : "", id : "", userId : ""})                

        }catch(error){
            console.error("Error:", error.message);
        }
        handleBackHome();
        navigate("/");

    }

    return (
        <>
        <div className="addAlbum-container" >
            <h2>Update your album :</h2>
            <form onSubmit={handleSubmit} >
            <input type = "text" 
                   placeholder="Enter album title" 
                   name = "title"
                   value = {albumData.title}
                   onChange={(e)=>setAlbumData({title : e.target.value, userId : albumData.userId})}
                   required/>
            <input type = "number" 
                   placeholder="Enter User ID" 
                   name = "userId"
                   value = {albumData.userId}
                   onChange = {(e)=> setAlbumData({title : albumData.title, userId : e.target.value})}
                   required/>
            <button className="btn" >Submit</button>
            </form>
        </div>
        
        </>
    )}

export default UpdateAlbum;
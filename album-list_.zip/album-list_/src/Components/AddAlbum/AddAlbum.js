import { useNavigate } from "react-router-dom";
import "./AddAlbum.css";
import {useState} from "react";
function AddAlbum({addAlbum, handleBackHome}){

    const [albumData, setAlbumData] = useState({title : "", userId : ""});
    const navigate = useNavigate();

    const handleSubmit = async (e)=>{
        e.preventDefault();
        try{
            const id = Date.now();
            const response = await fetch("https://jsonplaceholder.typicode.com/albums", {
                    method : "POST",
                    body : JSON.stringify({...albumData, id }),
                    headers : {
                        "Content-Type" : "application/json"
                    }
            })

            if(!response.ok){
                throw new Error("Failed to find an Album")
            }

            const newAlbum = await response.json();
            addAlbum(newAlbum);
            console.log("newAlbum:", newAlbum );
            setAlbumData({title : "", userId : ""})                

        }catch(error){
            console.error("Error:", error.message);
        }
        handleBackHome()
        navigate("/");

    }

    return (
        <>
        <div className="addAlbum-container" >
            <h2>Add new album :</h2>
            <form onSubmit={handleSubmit} >
            <input type = "text" 
                   placeholder="Enter album title" 
                   name = "title"
                   value = {albumData.title}
                   onChange={(e)=>setAlbumData({title : e.target.value, userId : albumData.userId})}
                   required/>
            <input type = "number" 
                   placeholder="Enter User ID" 
                   name = "id"
                   value = {albumData.id}
                   onChange = {(e)=> setAlbumData({title : albumData.title, userId : e.target.value})}
                   required/>
            <button className="btn" >Submit</button>
            </form>
        </div>
        
        </>
    )
}

export default AddAlbum;